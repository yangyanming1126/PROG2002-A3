module.exports = {
  host: "localhost",
  user: "root",
  password: "Lunyiyao20030110.",
  database : "crowdfunding_db"
};